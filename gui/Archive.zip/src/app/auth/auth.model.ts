export class AuthData{


email:string;
password:string;
}