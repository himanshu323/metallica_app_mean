export interface MarketPrice{

    account: string;
    price: Number;
    diff: string;

}