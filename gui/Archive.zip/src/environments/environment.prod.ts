export const environment = {
  production: true,
  apiUrl:"https://apigateway-metallica-app.herokuapp.com/",
  notifyService:"https://notifyservice-metallica-app.herokuapp.com/",
  marketDataService: "https://marketdataserv-metallica-app.herokuapp.com/"
};
